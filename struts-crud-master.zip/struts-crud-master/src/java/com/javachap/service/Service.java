package com.javachap.service;

import java.io.Serializable;

/**
 * Base Service
 * @author Varma
 */

public interface Service extends Serializable {

}
